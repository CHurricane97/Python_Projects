from requestsHttp.ZapytaniaMiast import *
from requestsHttp.ZapytaniaKrajow import *
