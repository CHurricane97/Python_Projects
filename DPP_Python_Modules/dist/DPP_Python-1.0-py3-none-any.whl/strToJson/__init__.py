from strToJson.WyswietlOdpowiedz import *
